

// FIX: Corrected the import syntax for useState and useEffect.
import React, { useState, useEffect } from 'react';
import { PlayCircle, X } from 'lucide-react';

interface AdPlayerModalProps {
    duration: number; // in seconds
    onComplete: () => void;
    onClose: () => void;
    adId: string;
}

const AdPlayerModal: React.FC<AdPlayerModalProps> = ({ duration, onComplete, onClose, adId }) => {
    const [countdown, setCountdown] = useState(duration);
    const [isComplete, setIsComplete] = useState(false);

    useEffect(() => {
        if (countdown > 0) {
            const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
            return () => clearTimeout(timer);
        } else if (!isComplete) { // Ensure onComplete is called only once
            setIsComplete(true);
            onComplete();
        }
    }, [countdown, onComplete, isComplete]);

    return (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[100] flex flex-col items-center justify-center p-4 animate-fadeIn">
            <div className="w-full max-w-md bg-black border-2 border-yellow-500/50 rounded-2xl shadow-2xl shadow-yellow-500/20 text-white">
                <div className="p-4 text-center">
                    <p className="text-sm text-gray-400">Rewarded Ad</p>
                    <div className="my-10 flex items-center justify-center">
                        <PlayCircle size={64} className="text-yellow-400 animate-pulse" />
                    </div>
                    <p className="text-xs text-gray-500 truncate">{adId}</p>
                </div>
                <div className="bg-black/40 p-3 flex items-center justify-between">
                    <p className="font-mono text-lg">
                        {isComplete ? 'Reward granted!' : `Reward in: ${countdown}s`}
                    </p>
                    <button 
                        onClick={onClose}
                        disabled={!isComplete}
                        className="p-2 rounded-full bg-gray-700 hover:bg-gray-600 transition disabled:opacity-50 disabled:cursor-not-allowed"
                        aria-label="Close ad"
                    >
                        <X size={20} />
                    </button>
                </div>
            </div>
             <style>{`
                @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
                .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default AdPlayerModal;
