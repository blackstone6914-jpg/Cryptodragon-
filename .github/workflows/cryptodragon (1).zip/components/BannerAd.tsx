import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { AdType } from '../types';

interface BannerAdProps {
    position: 'top' | 'bottom';
}

const BannerAd: React.FC<BannerAdProps> = ({ position }) => {
    const { getNextAdId } = useApp();
    const [adId, setAdId] = useState<string>('');

    useEffect(() => {
        setAdId(getNextAdId(AdType.BANNER));
    }, [getNextAdId]);

    return (
        <div className={`w-full h-16 bg-black/30 rounded-lg flex items-center justify-center text-gray-400 border border-blue-500/20 my-2`}>
            <div className="text-center">
                <p className="text-sm">Banner Ad</p>
                <p className="text-xs truncate max-w-xs opacity-50">{adId}</p>
            </div>
        </div>
    );
};

export default BannerAd;