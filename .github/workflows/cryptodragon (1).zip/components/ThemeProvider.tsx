import React, { useEffect, useLayoutEffect } from 'react';
import { useApp } from '../context/AppContext';
import { themes } from '../styles/themes';

const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { settings } = useApp();

    useLayoutEffect(() => {
        const themeName = settings.theme || 'DefaultDragon';
        const selectedTheme = themes.find(t => t.name === themeName) || themes[0];
        
        const root = document.documentElement;
        for (const [key, value] of Object.entries(selectedTheme.colors)) {
            root.style.setProperty(key, value);
        }

    }, [settings.theme]);

    return <>{children}</>;
};

export default ThemeProvider;
