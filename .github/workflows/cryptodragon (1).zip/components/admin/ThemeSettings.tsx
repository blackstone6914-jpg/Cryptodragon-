import React from 'react';
import { useApp } from '../../context/AppContext';
import { themes, Theme } from '../../styles/themes';
import { CheckCircle } from 'lucide-react';

const ThemeSettings: React.FC = () => {
    const { settings, updateSettings } = useApp();

    const handleThemeSelect = (themeName: string) => {
        updateSettings({ theme: themeName });
    };

    return (
        <div className="space-y-6">
            <h2 className="text-xl font-bold text-white font-orbitron">App Theme Customization</h2>
            <p className="text-gray-400">Select a theme to change the application's appearance for all users. The change is applied instantly.</p>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {themes.map((theme) => (
                    <div key={theme.name} className="relative">
                        <button
                            onClick={() => handleThemeSelect(theme.name)}
                            className={`w-full p-4 rounded-xl border-2 transition-all duration-200 ${
                                settings.theme === theme.name ? 'border-[var(--primary)] scale-105' : 'border-transparent hover:border-gray-600'
                            }`}
                        >
                            <div className="flex items-center justify-center h-16 rounded-lg" style={{ background: `linear-gradient(45deg, ${theme.colors['--gradient-accent1']}, ${theme.colors['--gradient-accent2']})` }}>
                                {/* You can add color dots here if you want */}
                            </div>
                            <p className="mt-3 font-semibold text-center">{theme.name}</p>
                        </button>
                        {settings.theme === theme.name && (
                             <div className="absolute top-2 right-2 p-1 bg-black/50 rounded-full">
                                <CheckCircle size={20} className="text-[var(--success)]" />
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ThemeSettings;
