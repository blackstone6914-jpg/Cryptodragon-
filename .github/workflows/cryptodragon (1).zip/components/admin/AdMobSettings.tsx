import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdMobIds, AdIdConfig } from '../../types';
import { Star } from 'lucide-react';

const Toggle: React.FC<{ enabled: boolean; onChange: (enabled: boolean) => void }> = ({ enabled, onChange }) => (
    <button
        onClick={() => onChange(!enabled)}
        className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${enabled ? 'bg-blue-600' : 'bg-gray-600'}`}
    >
        <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform duration-300 ease-in-out ${enabled ? 'translate-x-6' : 'translate-x-1'}`} />
    </button>
);


const AdMobSettings: React.FC = () => {
    const { adMobIds, updateAdMobIds, settings, updateSettings } = useApp();
    const [ids, setIds] = useState<AdMobIds>(adMobIds);
    const [adsEnabled, setAdsEnabled] = useState(settings.adsEnabled);
    const [testAdsEnabled, setTestAdsEnabled] = useState(settings.testAdsEnabled);
    const [highEcpmModeEnabled, setHighEcpmModeEnabled] = useState(settings.highEcpmModeEnabled);
    const [rotatingAdsEnabled, setRotatingAdsEnabled] = useState(settings.rotatingAdsEnabled);
    const [areIdsEditable, setAreIdsEditable] = useState(false);

    const handleIdChange = (type: keyof AdMobIds, index: number, value: string) => {
        const newIds = { ...ids };
        const newArray = [...newIds[type]];
        newArray[index] = { ...newArray[index], id: value };
        setIds({ ...ids, [type]: newArray });
    };

    const handleToggleChange = (type: keyof AdMobIds, index: number, enabled: boolean) => {
        const newIds = { ...ids };
        const newArray = [...newIds[type]];
        newArray[index] = { ...newArray[index], enabled };
        setIds({ ...ids, [type]: newArray });
    };

    const handleHighEcpmToggle = (type: keyof AdMobIds, index: number, isHighEcpm: boolean) => {
        const newIds = { ...ids };
        const newArray = [...newIds[type]];
        newArray[index] = { ...newArray[index], isHighEcpm };
        setIds({ ...ids, [type]: newArray });
    };


    const handleSave = async () => {
        await updateAdMobIds(ids);
        await updateSettings({
            adsEnabled,
            testAdsEnabled,
            highEcpmModeEnabled,
            rotatingAdsEnabled,
        });
        alert('AdMob settings updated!');
        setAreIdsEditable(false);
    };

    const renderIdList = (type: keyof AdMobIds, title: string) => (
        <div className="space-y-2">
            <h3 className="font-semibold text-lg text-blue-300 font-orbitron">{title}</h3>
            {ids[type].map((config, index) => (
                <div key={index} className="flex items-center gap-2 bg-black/30 p-2 rounded-lg">
                    <input
                        type="text"
                        value={config.id}
                        onChange={(e) => handleIdChange(type, index, e.target.value)}
                        className="flex-1 bg-black/40 p-2 rounded-md disabled:opacity-50"
                        disabled={!areIdsEditable}
                    />
                    <button onClick={() => handleHighEcpmToggle(type, index, !config.isHighEcpm)} title="Toggle High eCPM" className={`p-2 rounded-md ${config.isHighEcpm ? 'bg-yellow-500/30 text-yellow-300' : 'bg-gray-600/30 text-gray-400'}`}>
                        <Star size={16} />
                    </button>
                    <Toggle enabled={config.enabled} onChange={(enabled) => handleToggleChange(type, index, enabled)} />
                </div>
            ))}
        </div>
    );

    return (
        <div className="space-y-6">
            <h2 className="text-xl font-bold text-white font-orbitron">AdMob Settings</h2>
            
            <div className="bg-black/20 p-4 rounded-xl space-y-4">
                <div className="flex items-center justify-between">
                    <label className={`font-bold text-lg ${adsEnabled ? 'text-green-400' : 'text-red-400'}`}>
                        {adsEnabled ? 'Ads Enabled' : 'Ads Disabled'}
                    </label>
                    <Toggle enabled={adsEnabled} onChange={setAdsEnabled} />
                </div>
                 <div className="flex items-center justify-between">
                    <label className="text-gray-300">Test Ads Mode</label>
                    <Toggle enabled={testAdsEnabled} onChange={setTestAdsEnabled} />
                </div>
                <div className="flex items-center justify-between">
                    <label className="text-gray-300">High eCPM Priority Mode</label>
                    <Toggle enabled={highEcpmModeEnabled} onChange={setHighEcpmModeEnabled} />
                </div>
                 <div className="flex items-center justify-between">
                    <label className="text-gray-300">Rotating Mode</label>
                    <Toggle enabled={rotatingAdsEnabled} onChange={setRotatingAdsEnabled} />
                </div>
            </div>

            <div className={`space-y-4 transition-opacity ${!adsEnabled ? 'opacity-50 pointer-events-none' : ''}`}>
                <div className="flex justify-end">
                   <button onClick={() => setAreIdsEditable(!areIdsEditable)} className="bg-orange-600 hover:bg-orange-500 p-2 rounded-lg font-bold text-sm">
                       {areIdsEditable ? 'Lock IDs' : 'Edit IDs'}
                   </button>
                </div>
                {renderIdList('appIds', 'App IDs')}
                {renderIdList('bannerIds', 'Banner IDs')}
                {renderIdList('interstitialIds', 'Interstitial IDs')}
                {renderIdList('rewardedIds', 'Rewarded IDs')}
            </div>

            <button onClick={handleSave} className="w-full mt-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 p-3 rounded-lg font-bold text-lg font-orbitron">
                Save AdMob Settings
            </button>
        </div>
    );
};

export default AdMobSettings;