import React from 'react';

const NeonDragonSVG: React.FC<{ className?: string }> = ({ className }) => (
    <svg 
       className={className}
       viewBox="0 0 200 200"
       xmlns="http://www.w3.org/2000/svg"
       fill="none"
   >
       <defs>
           <filter id="neon-glow-splash" x="-50%" y="-50%" width="200%" height="200%">
               <feGaussianBlur stdDeviation="5" result="coloredBlur"/>
               <feMerge>
                   <feMergeNode in="coloredBlur"/>
                   <feMergeNode in="SourceGraphic"/>
               </feMerge>
           </filter>
           <linearGradient id="dragonGradient" x1="0%" y1="0%" x2="100%" y2="100%">
               <stop offset="0%" stopColor="var(--primary)" />
               <stop offset="100%" stopColor="var(--secondary)" />
           </linearGradient>
       </defs>
       <g filter="url(#neon-glow-splash)">
            <path d="M60 140 C 40 120, 30 90, 40 70 C 50 50, 80 40, 100 50 C 120 60, 130 80, 140 100" stroke="url(#dragonGradient)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M140 100 C 150 90, 160 80, 170 85 C 180 90, 175 105, 165 110 L 140 100" stroke="url(#dragonGradient)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M100 50 C 90 30, 110 20, 120 30" stroke="url(#dragonGradient)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="125" cy="75" r="5" fill="var(--accent)" />
            <path d="M60 140 C 80 160, 110 165, 130 150" stroke="url(#dragonGradient)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
       </g>
   </svg>
);


const SplashScreen: React.FC<{ onFadeOut: () => void }> = ({ onFadeOut }) => {
    return (
        <div className="fixed inset-0 z-[100] animated-gradient-bg flex flex-col items-center justify-center overflow-hidden animate-fadeOut" onAnimationEnd={onFadeOut}>
            <div className="absolute inset-0 particles">
                {[...Array(30)].map((_, i) => <div key={i} className="particle"></div>)}
            </div>
            
            <div className="relative animate-float3d">
                <NeonDragonSVG className="w-48 h-48" />
            </div>

            <h1 className="text-4xl mt-8 font-orbitron text-white animate-textGlow text-center shadow-[0_0_20px_var(--glow-1)]">
                Welcome to Crypto Dragon
            </h1>
            
            <style>{`
                .particles {
                    position: absolute;
                    width: 100%;
                    height: 100%;
                    overflow: hidden;
                }
                .particle {
                    position: absolute;
                    width: 4px;
                    height: 4px;
                    background-color: var(--accent);
                    border-radius: 50%;
                    opacity: 0;
                    animation: particle-animation 20s linear infinite;
                    box-shadow: 0 0 10px var(--accent);
                }
                ${[...Array(30)].map((_, i) => `
                    .particle:nth-child(${i + 1}) {
                        left: ${Math.random() * 100}%;
                        top: ${Math.random() * 100}%;
                        animation-delay: ${Math.random() * 20}s;
                        animation-duration: ${10 + Math.random() * 10}s;
                        transform: scale(${0.5 + Math.random()});
                    }
                `).join('')}

                @keyframes particle-animation {
                    0% { transform: translate(0, 0); opacity: 0; }
                    10% { opacity: 1; }
                    90% { opacity: 1; }
                    100% { transform: translate(${Math.random() * 200 - 100}px, ${Math.random() * 200 - 100}px); opacity: 0; }
                }

                @keyframes float3d {
                    0% { transform: translateY(0px) rotateY(0deg) scale(1); }
                    50% { transform: translateY(-20px) rotateY(20deg) scale(1.1); }
                    100% { transform: translateY(0px) rotateY(0deg) scale(1); }
                }
                .animate-float3d {
                    animation: float3d 6s ease-in-out infinite;
                    transform-style: preserve-3d;
                    perspective: 1000px;
                }
                
                @keyframes textGlow {
                    0%, 100% { 
                        opacity: 0;
                        text-shadow: 0 0 10px var(--glow-1), 0 0 20px var(--glow-2);
                    }
                    20%, 80% { 
                        opacity: 1;
                        text-shadow: 0 0 20px var(--glow-1), 0 0 30px var(--glow-2);
                    }
                }
                .animate-textGlow {
                    animation: textGlow 7s ease-in-out forwards;
                }
                
                @keyframes fadeOut {
                    0%, 90% { opacity: 1; pointer-events: auto; }
                    100% { opacity: 0; pointer-events: none; }
                }
                .animate-fadeOut {
                    animation: fadeOut 8s ease-in-out forwards;
                }

            `}</style>
        </div>
    );
};

export default SplashScreen;