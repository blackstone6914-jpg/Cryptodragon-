import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Share2, Copy, Gift, CheckCircle, Users, Link } from 'lucide-react';

const ReferralProgram: React.FC = () => {
    const { user, settings, applyReferralCode } = useApp();
    const [enteredCode, setEnteredCode] = useState('');
    const [feedback, setFeedback] = useState({ type: '', message: '' });
    const [isLoading, setIsLoading] = useState(false);

    if (!settings.referralProgramEnabled || !user) {
        return null;
    }

    const handleCopyCode = () => {
        navigator.clipboard.writeText(user.referralCode);
        setFeedback({ type: 'info', message: 'Your code has been copied!' });
        setTimeout(() => setFeedback({ type: '', message: '' }), 3000);
    };

    const handleShareLink = async () => {
        const shareUrl = `${window.location.origin}${window.location.pathname}?ref=${user.referralCode}`;
        const shareData = {
            title: `Join me on ${settings.appName}!`,
            text: `Join me on ${settings.appName} and get ${settings.refereeBonusCoins} coins for free when you sign up!`,
            url: shareUrl,
        };
        try {
            if (navigator.share) {
                await navigator.share(shareData);
            } else {
                await navigator.clipboard.writeText(shareUrl);
                setFeedback({ type: 'info', message: 'Referral link copied to clipboard!' });
                setTimeout(() => setFeedback({ type: '', message: '' }), 3000);
            }
        } catch (error) {
            console.error('Error sharing:', error);
            await navigator.clipboard.writeText(shareUrl);
            setFeedback({ type: 'info', message: 'Referral link copied to clipboard!' });
            setTimeout(() => setFeedback({ type: '', message: '' }), 3000);
        }
    };

    const handleSubmitCode = async () => {
        if (!enteredCode.trim()) {
            setFeedback({ type: 'error', message: 'Please enter a code.' });
            return;
        }
        setIsLoading(true);
        setFeedback({ type: '', message: '' });
        const result = await applyReferralCode(enteredCode);
        if (result.success) {
            setFeedback({ type: 'success', message: result.message });
        } else {
            setFeedback({ type: 'error', message: result.message });
        }
        setIsLoading(false);
    };

    const renderEnterCodeSection = () => {
        if (user.referredBy) {
            return (
                <div className="text-center p-4 bg-black/30 rounded-lg">
                    <CheckCircle className="mx-auto text-green-400 mb-2" size={28} />
                    <p className="font-semibold text-green-300">Welcome bonus received!</p>
                    <p className="text-sm text-gray-400">You were referred by code: {user.referredBy}</p>
                </div>
            );
        }

        return (
            <div className="space-y-3">
                <p className="font-semibold text-center">Been referred? Enter a code for a bonus!</p>
                <div className="flex gap-2">
                    <input
                        type="text"
                        placeholder="Enter referral code"
                        value={enteredCode}
                        onChange={(e) => setEnteredCode(e.target.value.toUpperCase())}
                        className="flex-grow bg-black/40 p-3 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[var(--primary)]"
                    />
                    <button
                        onClick={handleSubmitCode}
                        disabled={isLoading}
                        className="bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] px-4 rounded-lg font-bold text-white hover:opacity-90 disabled:opacity-50"
                    >
                        {isLoading ? '...' : 'Claim'}
                    </button>
                </div>
            </div>
        );
    };

    return (
        <div className="bg-black/30 p-4 rounded-2xl border border-[var(--primary)]/20 space-y-4">
            <div className="flex items-center gap-3">
                <Share2 size={24} className="text-[var(--primary)]" />
                <h2 className="text-2xl font-bold font-orbitron text-white">Refer & Earn</h2>
            </div>
            
            <p className="text-sm text-gray-300">
                Invite friends and you'll both get a bonus! You get <span className="font-bold text-yellow-300">{settings.referrerBonusCoins.toLocaleString()}</span> coins, and your friend gets <span className="font-bold text-yellow-300">{settings.refereeBonusCoins.toLocaleString()}</span> coins.
            </p>

            <div className="bg-black/20 p-3 rounded-lg space-y-2">
                 <p className="text-sm text-gray-400 text-center">Your unique referral code:</p>
                 <div className="flex items-center justify-center gap-2">
                    <p className="text-2xl font-bold tracking-widest bg-black/40 px-4 py-2 rounded-md font-orbitron">{user.referralCode}</p>
                    <button onClick={handleCopyCode} title="Copy Code" className="p-3 bg-black/40 rounded-md hover:bg-black/60"><Copy size={20} /></button>
                     <button onClick={handleShareLink} title="Share Link" className="p-3 bg-black/40 rounded-md hover:bg-black/60"><Link size={20} /></button>
                 </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3 text-center">
                <div className="bg-black/20 p-2 rounded-lg">
                    <Users size={20} className="mx-auto text-[var(--secondary)] mb-1" />
                    <p className="font-bold text-lg">{user.referralsCount}</p>
                    <p className="text-xs text-gray-400">Friends Joined</p>
                </div>
                <div className="bg-black/20 p-2 rounded-lg">
                    <Gift size={20} className="mx-auto text-[var(--accent)] mb-1" />
                    <p className="font-bold text-lg">{user.referralBonusEarned.toLocaleString()}</p>
                    <p className="text-xs text-gray-400">Bonus Earned</p>
                </div>
            </div>

            <div className="border-t border-[var(--primary)]/20 pt-4">
                {renderEnterCodeSection()}
            </div>

            {feedback.message && (
                 <p className={`text-center text-sm font-semibold ${feedback.type === 'success' ? 'text-green-400' : feedback.type === 'error' ? 'text-red-400' : 'text-blue-300'}`}>
                    {feedback.message}
                </p>
            )}

        </div>
    );
};

export default ReferralProgram;