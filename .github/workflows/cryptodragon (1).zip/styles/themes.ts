export interface Theme {
    name: string;
    colors: {
        '--bg-dark': string;
        '--gradient-start': string;
        '--gradient-mid': string;
        '--gradient-accent1': string;
        '--gradient-accent2': string;
        '--primary': string;
        '--secondary': string;
        '--accent': string;
        '--success': string;
        '--glow-1': string;
        '--glow-2': string;
    }
}

export const themes: Theme[] = [
    {
        name: 'DefaultDragon',
        colors: {
            '--bg-dark': '#0D0D0D',
            '--gradient-start': '#0d0d0d',
            '--gradient-mid': '#1a1a1a',
            '--gradient-accent1': '#8A2BE2',
            '--gradient-accent2': '#1E90FF',
            '--primary': '#1E90FF',
            '--secondary': '#8A2BE2',
            '--accent': '#FFD700',
            '--success': '#28a745',
            '--glow-1': 'rgba(30, 144, 255, 0.7)',
            '--glow-2': 'rgba(138, 43, 226, 0.7)',
        }
    },
    {
        name: 'OceanicBlue',
        colors: {
            '--bg-dark': '#02101d',
            '--gradient-start': '#02101d',
            '--gradient-mid': '#041d33',
            '--gradient-accent1': '#0077b6',
            '--gradient-accent2': '#00b4d8',
            '--primary': '#00b4d8',
            '--secondary': '#0077b6',
            '--accent': '#90e0ef',
            '--success': '#48cae4',
            '--glow-1': 'rgba(0, 180, 216, 0.7)',
            '--glow-2': 'rgba(0, 119, 182, 0.7)',
        }
    },
    {
        name: 'RoyalPurple',
        colors: {
            '--bg-dark': '#191029',
            '--gradient-start': '#191029',
            '--gradient-mid': '#2d1b4d',
            '--gradient-accent1': '#7209b7',
            '--gradient-accent2': '#560bad',
            '--primary': '#7209b7',
            '--secondary': '#f72585',
            '--accent': '#b5179e',
            '--success': '#4cc9f0',
            '--glow-1': 'rgba(114, 9, 183, 0.7)',
            '--glow-2': 'rgba(247, 37, 133, 0.7)',
        }
    },
    {
        name: 'EmeraldGreen',
        colors: {
            '--bg-dark': '#011c0f',
            '--gradient-start': '#011c0f',
            '--gradient-mid': '#032e18',
            '--gradient-accent1': '#008000',
            '--gradient-accent2': '#55a630',
            '--primary': '#55a630',
            '--secondary': '#008000',
            '--accent': '#aacc00',
            '--success': '#70e000',
            '--glow-1': 'rgba(85, 166, 48, 0.7)',
            '--glow-2': 'rgba(0, 128, 0, 0.7)',
        }
    },
    {
        name: 'GoldenSun',
        colors: {
            '--bg-dark': '#291b00',
            '--gradient-start': '#291b00',
            '--gradient-mid': '#4d3302',
            '--gradient-accent1': '#ff8c00',
            '--gradient-accent2': '#ffb703',
            '--primary': '#ffb703',
            '--secondary': '#ff8c00',
            '--accent': '#fb8500',
            '--success': '#219ebc',
            '--glow-1': 'rgba(255, 183, 3, 0.7)',
            '--glow-2': 'rgba(255, 140, 0, 0.7)',
        }
    },
    {
        name: 'RubyRed',
        colors: {
            '--bg-dark': '#240000',
            '--gradient-start': '#240000',
            '--gradient-mid': '#490101',
            '--gradient-accent1': '#d00000',
            '--gradient-accent2': '#9d0208',
            '--primary': '#d00000',
            '--secondary': '#dc2f02',
            '--accent': '#f48c06',
            '--success': '#e85d04',
            '--glow-1': 'rgba(208, 0, 0, 0.7)',
            '--glow-2': 'rgba(220, 47, 2, 0.7)',
        }
    },
    {
        name: 'CyberPunk',
        colors: {
            '--bg-dark': '#0c0c0c',
            '--gradient-start': '#0c0c0c',
            '--gradient-mid': '#1a001a',
            '--gradient-accent1': '#ff00ff',
            '--gradient-accent2': '#00ffff',
            '--primary': '#ff00ff',
            '--secondary': '#00ffff',
            '--accent': '#ffff00',
            '--success': '#00ff00',
            '--glow-1': 'rgba(0, 255, 255, 0.7)',
            '--glow-2': 'rgba(255, 0, 255, 0.7)',
        }
    },
    {
        name: 'CosmicVoid',
        colors: {
            '--bg-dark': '#0b0014',
            '--gradient-start': '#0b0014',
            '--gradient-mid': '#190028',
            '--gradient-accent1': '#43006a',
            '--gradient-accent2': '#6f00b1',
            '--primary': '#6f00b1',
            '--secondary': '#9d4edd',
            '--accent': '#c77dff',
            '--success': '#e0aaff',
            '--glow-1': 'rgba(111, 0, 177, 0.7)',
            '--glow-2': 'rgba(157, 78, 221, 0.7)',
        }
    },
    {
        name: 'SakuraPink',
        colors: {
            '--bg-dark': '#211522',
            '--gradient-start': '#211522',
            '--gradient-mid': '#442244',
            '--gradient-accent1': '#ff75a6',
            '--gradient-accent2': '#ffc2d4',
            '--primary': '#ff75a6',
            '--secondary': '#ffc2d4',
            '--accent': '#f9bec7',
            '--success': '#e56b6f',
            '--glow-1': 'rgba(255, 117, 166, 0.7)',
            '--glow-2': 'rgba(255, 194, 212, 0.7)',
        }
    },
    {
        name: 'VolcanicOrange',
        colors: {
            '--bg-dark': '#1a1a1a',
            '--gradient-start': '#1a1a1a',
            '--gradient-mid': '#2b2b2b',
            '--gradient-accent1': '#ff4500',
            '--gradient-accent2': '#ff6347',
            '--primary': '#ff4500',
            '--secondary': '#ff6347',
            '--accent': '#ffa500',
            '--success': '#ff8c00',
            '--glow-1': 'rgba(255, 69, 0, 0.7)',
            '--glow-2': 'rgba(255, 99, 71, 0.7)',
        }
    },
    {
        name: 'ArcticAurora',
        colors: {
            '--bg-dark': '#0a1014',
            '--gradient-start': '#0a1014',
            '--gradient-mid': '#101a23',
            '--gradient-accent1': '#4dffaf',
            '--gradient-accent2': '#42a5f5',
            '--primary': '#4dffaf',
            '--secondary': '#42a5f5',
            '--accent': '#f0f4c3',
            '--success': '#69f0ae',
            '--glow-1': 'rgba(77, 255, 175, 0.7)',
            '--glow-2': 'rgba(66, 165, 245, 0.6)',
        }
    },
    {
        name: 'Inferno',
        colors: {
            '--bg-dark': '#100800',
            '--gradient-start': '#100800',
            '--gradient-mid': '#2d0f00',
            '--gradient-accent1': '#ff4800',
            '--gradient-accent2': '#ff1d15',
            '--primary': '#ff4800',
            '--secondary': '#ff1d15',
            '--accent': '#ffd60a',
            '--success': '#ff8400',
            '--glow-1': 'rgba(255, 72, 0, 0.7)',
            '--glow-2': 'rgba(255, 29, 21, 0.7)',
        }
    },
    {
        name: 'MatrixCode',
        colors: {
            '--bg-dark': '#000000',
            '--gradient-start': '#020202',
            '--gradient-mid': '#050a05',
            '--gradient-accent1': '#00ff00',
            '--gradient-accent2': '#008f11',
            '--primary': '#00ff00',
            '--secondary': '#00c22d',
            '--accent': '#c0ffc0',
            '--success': '#39ff14',
            '--glow-1': 'rgba(0, 255, 0, 0.7)',
            '--glow-2': 'rgba(57, 255, 20, 0.5)',
        }
    },
    {
        name: 'StarlightWhite',
        colors: {
            '--bg-dark': '#111111',
            '--gradient-start': '#111111',
            '--gradient-mid': '#222222',
            '--gradient-accent1': '#cccccc',
            '--gradient-accent2': '#eeeeee',
            '--primary': '#ffffff',
            '--secondary': '#bbbbbb',
            '--accent': '#00aaff',
            '--success': '#44dd88',
            '--glow-1': 'rgba(255, 255, 255, 0.6)',
            '--glow-2': 'rgba(200, 200, 200, 0.4)',
        }
    },
    {
        name: 'RainbowBurst',
        colors: {
            '--bg-dark': '#101010',
            '--gradient-start': '#ff0000',
            '--gradient-mid': '#ff7f00',
            '--gradient-accent1': '#00ff00',
            '--gradient-accent2': '#0000ff',
            '--primary': '#e040fb',
            '--secondary': '#ffab40',
            '--accent': '#18ffff',
            '--success': '#76ff03',
            '--glow-1': 'rgba(224, 64, 251, 0.7)',
            '--glow-2': 'rgba(24, 255, 255, 0.7)',
        }
    },
    {
        name: 'SynthwaveSunset',
        colors: {
            '--bg-dark': '#200a3e',
            '--gradient-start': '#200a3e',
            '--gradient-mid': '#3b125f',
            '--gradient-accent1': '#f92a82',
            '--gradient-accent2': '#ffae42',
            '--primary': '#f92a82',
            '--secondary': '#00d2ff',
            '--accent': '#ffae42',
            '--success': '#7df9ff',
            '--glow-1': 'rgba(249, 42, 130, 0.7)',
            '--glow-2': 'rgba(0, 210, 255, 0.7)',
        }
    },
    {
        name: 'TropicalVibes',
        colors: {
            '--bg-dark': '#00122d',
            '--gradient-start': '#00122d',
            '--gradient-mid': '#00255a',
            '--gradient-accent1': '#ff6b6b',
            '--gradient-accent2': '#fca311',
            '--primary': '#4ecdc4',
            '--secondary': '#ff6b6b',
            '--accent': '#fca311',
            '--success': '#a2d2ff',
            '--glow-1': 'rgba(78, 205, 196, 0.7)',
            '--glow-2': 'rgba(255, 107, 107, 0.7)',
        }
    }
];